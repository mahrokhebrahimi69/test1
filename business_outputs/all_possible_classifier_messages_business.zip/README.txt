Excel business handoff for classifier examples.

Rows: 2059
Includes original test suite rows plus generated Persian/English business examples.
Workbook: all_possible_classifier_messages_business.xlsx
